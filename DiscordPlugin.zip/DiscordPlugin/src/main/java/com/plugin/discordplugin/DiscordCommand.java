package com.plugin.discordplugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DiscordCommand implements CommandExecutor {

    private final DiscordPlugin plugin;

    public DiscordCommand(DiscordPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        String discordLink   = plugin.getDiscordLink();
        String serverName    = plugin.getDiscordServerName();

        // ──────────────────────────────────────────────────────────────────
        // Discord logosu ASCII sanatı (Minecraft renk kodlarıyla)
        // Renk: &9 = mavi (Discord rengi)
        // ──────────────────────────────────────────────────────────────────

        String[] logo = {
            "&9  &l██████╗ &r&9 &l██╗&r&9 &l███████╗&r&9 &l ██████╗ &r&9 &l██████╗ &r&9 &l██████╗ &r&9 &l██████╗ ",
            "&9  &l██╔══██╗&r&9&l██║&r&9 &l██╔════╝&r&9&l██╔════╝ &r&9&l██╔══██╗&r&9&l╚════██╗&r&9&l╚════██╗",
            "&9  &l██║  ██║&r&9&l██║&r&9 &l███████╗&r&9&l██║      &r&9&l██║  ██║&r&9 &l█████╔╝&r&9 &l█████╔╝",
            "&9  &l██║  ██║&r&9&l██║&r&9 &l╚════██║&r&9&l██║      &r&9&l██║  ██║&r&9 &l╚═══██╗&r&9 &l╚═══██╗",
            "&9  &l██████╔╝&r&9&l██║&r&9 &l███████║&r&9&l╚██████╗ &r&9&l██████╔╝&r&9&l██████╔╝&r&9&l██████╔╝",
            "&9  &l╚═════╝ &r&9&l╚═╝&r&9 &l╚══════╝&r&9 &l╚═════╝ &r&9&l╚═════╝ &r&9&l╚═════╝ &r&9&l╚═════╝ "
        };

        // Discord ikon (küçük, compakt versiyon - her zaman görünür)
        String[] icon = {
            "     &9&l  ██████████████  ",
            "     &9&l ████████████████ ",
            "     &9&l██  &b●&9&l     &b●&9&l  ██",
            "     &9&l██    &b◕    ◕&9&l   ██",
            "     &9&l ████████████████ ",
            "     &9&l  ████  ██  ████  "
        };

        // Mesaj gönder
        sender.sendMessage("");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));

        // Discord logo (büyük ekranlarda güzel durur)
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l╔══════════════════════════╗"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b  ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄     &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b ██████████████████    &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b ██  &f●&b        &f●&b  ██   &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b ██    &f( ͡° ͜ʖ ͡°)&b   ██   &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b  ████████████████     &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║  &b   ████      ████      &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l╠══════════════════════════╣"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l║   &f&lD I S C O R D          &9&l║"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "         &9&l╚══════════════════════════╝"));

        sender.sendMessage("");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "  &f&l» &b" + serverName + " &f&lDiscord Sunucusu"));
        sender.sendMessage("");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "  &7Bize katılmak için aşağıdaki linki kullan:"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "  &b&l» " + discordLink));
        sender.sendMessage("");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "  &7&o• Destek, duyurular ve daha fazlası için!"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "  &7&o• Sunucumuza katıl ve topluluğun parçası ol!"));
        sender.sendMessage("");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage("");

        // Eğer konsol yazdıysa bilgilendir
        if (!(sender instanceof Player)) {
            sender.sendMessage("[DiscordPlugin] Discord linki: " + discordLink);
        }

        return true;
    }
}
