package com.plugin.discordplugin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PlayerJoinListener implements Listener {

    private final DiscordPlugin plugin;

    public PlayerJoinListener(DiscordPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Sonsuz Gece Görüşü ver (Integer.MAX_VALUE = sonsuz süre)
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.NIGHT_VISION,
                Integer.MAX_VALUE, // Süre - sonsuz
                0,                 // Seviye (0 = I)
                false,             // Ambient
                false              // Particles kapalı (temiz görünüm)
        ));

        // Hoşgeldin mesajı
        player.sendMessage("");
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l┌─────────────────────────────────┐"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l│  &b✦ &fHoş geldin, &b" + player.getName() + "&f! &b✦  &8&l│"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l│  &7Sonsuz gece görüşü verildi! &a✔  &8&l│"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l│  &7Discord için: &b/discord &8&l          │"));
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&l└─────────────────────────────────┘"));
        player.sendMessage("");
    }
}
