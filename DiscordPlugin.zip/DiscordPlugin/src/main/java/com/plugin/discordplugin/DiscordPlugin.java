package com.plugin.discordplugin;

import org.bukkit.plugin.java.JavaPlugin;

public class DiscordPlugin extends JavaPlugin {

    private static DiscordPlugin instance;

    @Override
    public void onEnable() {
        instance = this;

        // Config oluştur (yoksa)
        saveDefaultConfig();

        // Komut ve Event kayıtları
        getCommand("discord").setExecutor(new DiscordCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);

        getLogger().info("§a✔ DiscordPlugin başarıyla yüklendi!");
        getLogger().info("§bDiscord: " + getDiscordLink());
    }

    @Override
    public void onDisable() {
        getLogger().info("§cDiscordPlugin kapatıldı.");
    }

    public static DiscordPlugin getInstance() {
        return instance;
    }

    public String getDiscordLink() {
        return getConfig().getString("discord.link", "https://discord.gg/example");
    }

    public String getDiscordServerName() {
        return getConfig().getString("discord.server-name", "Sunucumuz");
    }
}
