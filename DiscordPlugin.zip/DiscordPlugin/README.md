# 🎮 DiscordPlugin - Minecraft Spigot Plugin

## ✅ Özellikler
- **Oyuncu girişinde sonsuz gece görüşü** (Night Vision)
- **/discord komutu** → Discord logolu süslü mesaj
- **config.yml** üzerinden Discord linki ve sunucu adı ayarlanabilir

---

## 📦 Kurulum

### 1. Derleme (Maven ile)
```bash
mvn clean package
```
Çıktı: `target/DiscordPlugin-1.0.0.jar`

### 2. Sunucuya Yükleme
1. `.jar` dosyasını sunucunun `plugins/` klasörüne koy
2. Sunucuyu başlat veya `/reload` yap
3. `plugins/DiscordPlugin/config.yml` dosyasını aç
4. Discord linkini ve sunucu adını düzenle
5. `/reload` veya sunucuyu yeniden başlat

---

## ⚙️ Config (config.yml)
```yaml
discord:
  server-name: "Benim Sunucum"       # /discord'da çıkacak sunucu adı
  link: "https://discord.gg/xxxxx"   # Discord davet linki
```

---

## 📋 Komutlar
| Komut | Açıklama | Alias |
|-------|----------|-------|
| `/discord` | Discord linkini gösterir | `/dc`, `/dis` |

---

## 🔧 Uyumluluk
- **Minecraft:** 1.13 - 1.20+
- **Platform:** Spigot / Paper / Purpur
- **Java:** 8+

---

## 🌙 Gece Görüşü
Oyuncu sunucuya girdiğinde otomatik olarak:
- Sonsuz Night Vision effect verilir (particles kapalı, temiz görünüm)
- Hoşgeldin mesajı gönderilir

---

*DiscordPlugin v1.0.0*
