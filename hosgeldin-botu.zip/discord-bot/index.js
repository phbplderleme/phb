const { Client, GatewayIntentBits, EmbedBuilder, AttachmentBuilder, PermissionsBitField } = require('discord.js');
const Canvas = require('@napi-rs/canvas');
const path = require('path');
const fs = require('fs');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// =============================================
// ⚙️  AYARLAR — sadece buraya dokunun!
// =============================================
const CONFIG = {
  token: process.env.DISCORD_TOKEN || 'BURAYA_BOT_TOKENINI_YAZ',
  welcomeChannelName: 'hoş-geldiniz',   // Hoşgeldin kanalının adı
  welcomeChannelId: '',                  // Opsiyonel: kanal ID ile de ayarlayabilirsiniz
  color: '#5865F2',                      // Embed rengi (Discord Blurple)
  bannerImage: './assets/banner.png',    // Sunucu banner görseli (opsiyonel)
};
// =============================================

// -----------------------------------------------
// Hoşgeldin görseli oluştur (Canvas)
// -----------------------------------------------
async function createWelcomeImage(member) {
  const canvas = Canvas.createCanvas(900, 300);
  const ctx = canvas.getContext('2d');

  // Arka plan gradyan
  const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, '#0d1117');
  gradient.addColorStop(0.5, '#161b22');
  gradient.addColorStop(1, '#1c2128');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Dekoratif çizgiler
  ctx.strokeStyle = 'rgba(88, 101, 242, 0.3)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(0, 50 * i);
    ctx.lineTo(canvas.width, 50 * i);
    ctx.stroke();
  }

  // Sol parlama efekti
  const glow = ctx.createRadialGradient(150, 150, 0, 150, 150, 200);
  glow.addColorStop(0, 'rgba(88, 101, 242, 0.25)');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, 400, canvas.height);

  // Avatar çemberi arka planı (halo efekti)
  ctx.save();
  ctx.shadowColor = '#5865F2';
  ctx.shadowBlur = 30;
  ctx.beginPath();
  ctx.arc(150, 150, 100, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(88,101,242,0.15)';
  ctx.fill();
  ctx.restore();

  // Avatar çemberi kenar
  ctx.beginPath();
  ctx.arc(150, 150, 98, 0, Math.PI * 2);
  ctx.strokeStyle = '#5865F2';
  ctx.lineWidth = 4;
  ctx.stroke();

  // Avatar resmi
  try {
    const avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
    const avatar = await Canvas.loadImage(avatarUrl);
    ctx.save();
    ctx.beginPath();
    ctx.arc(150, 150, 94, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(avatar, 56, 56, 188, 188);
    ctx.restore();
  } catch {
    ctx.fillStyle = '#5865F2';
    ctx.beginPath();
    ctx.arc(150, 150, 94, 0, Math.PI * 2);
    ctx.fill();
  }

  // HOŞGELDİN başlığı
  ctx.font = 'bold 22px sans-serif';
  ctx.fillStyle = '#5865F2';
  ctx.letterSpacing = '6px';
  ctx.fillText('✦  HOŞGELDİN  ✦', 300, 90);

  // Kullanıcı adı
  ctx.font = 'bold 38px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.letterSpacing = '0px';
  const username = member.user.username.length > 18
    ? member.user.username.slice(0, 18) + '…'
    : member.user.username;
  ctx.fillText(username, 300, 148);

  // Etiket çizgisi
  ctx.fillStyle = '#5865F2';
  ctx.fillRect(300, 162, 340, 3);

  // Sunucu ve üye bilgisi
  ctx.font = '18px sans-serif';
  ctx.fillStyle = '#8b949e';
  ctx.fillText(`${member.guild.name} sunucusuna katıldı`, 300, 200);

  ctx.font = 'bold 18px sans-serif';
  ctx.fillStyle = '#5865F2';
  ctx.fillText(`#${member.guild.memberCount}. üye 🎉`, 300, 232);

  return canvas.toBuffer('image/png');
}

// -----------------------------------------------
// Üye katılma olayı
// -----------------------------------------------
client.on('guildMemberAdd', async (member) => {
  try {
    // Hoşgeldin kanalını bul
    let welcomeChannel = CONFIG.welcomeChannelId
      ? member.guild.channels.cache.get(CONFIG.welcomeChannelId)
      : member.guild.channels.cache.find(
          (ch) => ch.name === CONFIG.welcomeChannelName
        );

    if (!welcomeChannel) {
      console.log(`⚠️  Hoşgeldin kanalı bulunamadı! Kanal adı: "${CONFIG.welcomeChannelName}"`);
      return;
    }

    // Görsel oluştur
    const imageBuffer = await createWelcomeImage(member);
    const attachment = new AttachmentBuilder(imageBuffer, { name: 'hosgeldin.png' });

    // Embed mesaj
    const embed = new EmbedBuilder()
      .setColor(CONFIG.color)
      .setTitle(`🎊  ${member.user.username} sunucuya katıldı!`)
      .setDescription(
        `> Merhaba ${member}! **${member.guild.name}** ailesine hoş geldin!\n` +
        `> Kuralları okumayı ve kanalları keşfetmeyi unutma. 🚀`
      )
      .addFields(
        { name: '👤 Kullanıcı', value: `${member.user.tag}`, inline: true },
        { name: '🆔 ID', value: `\`${member.user.id}\``, inline: true },
        { name: '👥 Üye Sayısı', value: `**${member.guild.memberCount}** kişi`, inline: true },
        { name: '📅 Hesap Açılış', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '📥 Katılım', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
      )
      .setImage('attachment://hosgeldin.png')
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .setFooter({ text: `${member.guild.name} • Üye #${member.guild.memberCount}`, iconURL: member.guild.iconURL() })
      .setTimestamp();

    await welcomeChannel.send({ embeds: [embed], files: [attachment] });
    console.log(`✅  ${member.user.tag} için hoşgeldin mesajı gönderildi.`);
  } catch (err) {
    console.error('❌  Hoşgeldin mesajı gönderilemedi:', err);
  }
});

// -----------------------------------------------
// !setwelcome komutu — hoşgeldin kanalını ayarla
// -----------------------------------------------
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith('!')) return;

  const args = message.content.slice(1).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // !setwelcome — komutu çalıştıran kişi bu kanalı hoşgeldin kanalı yapar
  if (command === 'setwelcome') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine ihtiyacın var.');
    }
    CONFIG.welcomeChannelId = message.channel.id;
    return message.reply(`✅ Hoşgeldin kanalı **bu kanal** olarak ayarlandı! (${message.channel})`);
  }

  // !addchannel <isim> — yeni bir kanal oluştur
  if (command === 'addchannel') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine ihtiyacın var.');
    }
    const channelName = args.join('-').toLowerCase().replace(/[^a-z0-9ğüşıöç-]/gi, '').replace(/ /g, '-') || 'yeni-kanal';
    try {
      const newChannel = await message.guild.channels.create({
        name: channelName,
        type: 0, // GUILD_TEXT
        reason: `${message.author.tag} tarafından !addchannel ile oluşturuldu`,
      });
      return message.reply(`✅ **${newChannel}** kanalı başarıyla oluşturuldu!`);
    } catch (err) {
      return message.reply('❌ Kanal oluşturulamadı. Botun **Kanalları Yönet** yetkisi var mı?');
    }
  }

  // !botinfo — bot bilgisi
  if (command === 'botinfo') {
    const embed = new EmbedBuilder()
      .setColor(CONFIG.color)
      .setTitle('🤖 Bot Bilgisi')
      .addFields(
        { name: '📡 Sunucu', value: message.guild.name, inline: true },
        { name: '👥 Üye', value: `${message.guild.memberCount}`, inline: true },
        { name: '🟢 Durum', value: 'Çevrimiçi', inline: true },
      )
      .setFooter({ text: 'Hoşgeldin Botu' })
      .setTimestamp();
    return message.reply({ embeds: [embed] });
  }
});

// -----------------------------------------------
// Bot hazır
// -----------------------------------------------
client.once('ready', () => {
  console.log(`\n🚀  Bot aktif: ${client.user.tag}`);
  console.log(`📡  ${client.guilds.cache.size} sunucuda çalışıyor\n`);
  client.user.setActivity('Sunucuyu Koruyor 🛡️', { type: 3 });
});

client.login(CONFIG.token);
